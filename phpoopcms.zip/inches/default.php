<h1><a href="#">Default</a></h1>
<!--
<h3>posted by <a href="#">anonynous anon</a> under <a href="#">categories</a>, <a href="#">articles</a>, <a href="#">poems</a>, <a href="#">research</a> on 13th August 2006</h3>
<p class="desc">A descriptive line about a content... which will tell what to expect or what the author is tying to show off witht he content written below it.</p>
<p>Any content that does not fit in a fixed-width or -height box causes the box to expand to fit the content. (The content should overflow instead.)</p>
<p>Use word-wrap: break-word inside IE-conditional comments (works on text only) or overflow: hidden (works on all content, but may cause content to be clipped).</p>
<p class="code"> &lt;?php echo('Hello'); ?&gt; </p>
<p>Any content that does not fit in a fixed-width or -height box causes the box to expand to fit the content. (The content should overflow instead.)</p>
<p>Use word-wrap: break-word inside IE-conditional comments (works on text only) or overflow: hidden (works on all content, but may cause content to be clipped).</p>
<div class="postfoot">
    <p> 24 Comments </p>
</div>
<div class="postfoot">
    <p> Tagged under: <a href="#">css</a>, <a href="#">js</a> </p>
</div>
<div id="basic" class="myform">
<form id="form1" name="form1" method="post" action="submit.php">
<h2>Comments form</h2>
<p>Please post your comments about the post</p>
<label>Name <span class="small">Add your name</span> </label>
<input type="text" name="txtName" id="name" />
<label>Email <span class="small">Add a valid address</span> </label>
<input type="text" name="txtEmail" id="email" />
<label>Comments <span class="small">Min. size 6 chars</span> </label>
<textarea name="txtComments" cols="1" rows="1"></textarea>
<button  type="submit">Post Comments</button>
</form>
</div>-->
<?php
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', 'vert');
define('DBNAME', 'swap');
define('HTTP_SERVER', 'http://localhost/phpoopcms/');
define('INCLUDES', 'inches/');
define('FUNCTIONS', INCLUDES . 'functions/');
define('CLASSES', INCLUDES . 'classes/');
?>
<div id="basic" class="myform">
<form id="form1" name="form1" method="post" action="<?php echo $PHP_SELF; ?>">
<h2>Login Form</h2>
<p>Please enter the appropriate login details below</p>
<label>User Name <span class="small">Enter username</span> </label>
<input class="txt" type="text" name="txtUsername" id="name" value="" />
<label>Password<span class="small">Enter password</span> </label>
<input class="txt" type="password" name="txtPassword" id="password" value="" />
<input class="btn" type="submit" name="btnLogin" value="Login" />
</form>
</div>
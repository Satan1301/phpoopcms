<?php
    class SiteRss {

    }
?>
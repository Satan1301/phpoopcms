<?php
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBPASS', 'vert');
define('DBNAME', 'swap');
define('HTTP_SERVER', 'http://localhost/phpoopcms/admin/');

define('INCLUDES', 'inches/');
define('FUNCTIONS', INCLUDES . 'functions/');
define('CLASSES', INCLUDES . 'classes/');
define('PER_PAGE', 3);
define('WEBSITE_TITLE', '');
define('USERNAME', 'username');
define('PASSWORD', 'password');
define('UPLOAD_DIR', '../images/');
date_default_timezone_set('Asia/Kolkata');
?>